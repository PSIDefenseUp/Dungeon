﻿using UnityEngine;
using System.Collections;

public interface IMainPhase : IPlayerPhase
{ 

}
